import tkinter as tk
from tkinter import ttk
import sqlite3


class Main(tk.Frame):
    def __init__(self, root):
        super().__init__(root)
        self.init_main()
        self.db = db
        self.view_records()

    def init_main(self):
        toolbar = tk.Frame(bg='#d7d8e0', bd=2)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        self.add_img = tk.PhotoImage(file='')
        btn_open_dialog = tk.Button(toolbar, text='Добавить позицию', command=self.open_dialog, bg='#d7d8e0', bd=0,
                                    compound=tk.TOP, image=self.add_img)
        btn_open_dialog.pack(side=tk.LEFT)

        self.update_img = tk.PhotoImage(file='')
        btn_edit_dialog = tk.Button(toolbar, text='Добавить пробег', bg='#d7d8e0', bd=0, image=self.update_img,
                                    compound=tk.TOP, command=self.open_update_dialog)
        btn_edit_dialog.pack(side=tk.LEFT)

        self.delete_img = tk.PhotoImage(file='')
        btn_delete = tk.Button(toolbar, text='Удалить позицию', bg='#d7d8e0', bd=0, image=self.delete_img,
                               compound=tk.TOP, command=self.delete_records)
        btn_delete.pack(side=tk.LEFT)

        self.search_img = tk.PhotoImage(file='')
        btn_search = tk.Button(toolbar, text='Поиск', bg='#d7d8e0', bd=0, image=self.search_img,
                               compound=tk.TOP, command=self.open_search_dialog)
        btn_search.pack(side=tk.LEFT)

        self.refresh_img = tk.PhotoImage(file='')
        btn_refresh = tk.Button(toolbar, text='Обновить', bg='#d7d8e0', bd=0, image=self.refresh_img,
                                compound=tk.TOP, command=self.view_records)
        btn_refresh.pack(side=tk.LEFT)

        self.tree = ttk.Treeview(self, columns=('ID', 'description', 'total', 'before', 'exam'), height=15,
                                 show='headings')

        self.tree.column('ID', width=30, anchor=tk.CENTER)
        self.tree.column('description', width=365, anchor=tk.CENTER)
        self.tree.column('total', width=100, anchor=tk.CENTER)
        self.tree.column('before', width=100, anchor=tk.CENTER)
        self.tree.column('exam', width=100, anchor=tk.CENTER)

        self.tree.heading('ID', text='ID')
        self.tree.heading('description', text='Наименование')
        self.tree.heading('total', text='Общий пробег')
        self.tree.heading('before', text='Пробег до ТО')
        self.tree.heading('exam', text='Кол-во ТО')

        self.tree.pack()

    def records(self, description, total, before, exam):
        self.db.insert_data(description, total, before, exam)
        self.view_records()

    def update_record(self, add):
        t = self.tree.set
        b = list(self.db.c.execute('''select * from BeforeExam WHERE ID=?''',
                                   (t(self.tree.selection()[0], '#1'))))[0][2]
        l = list(self.db.c.execute('''SELECT * FROM finance where ID=?''', (t(self.tree.selection()[0], '#1'))))[0]
        to, be, ex = [int(i) for i in l[-3:]]
        to += float(add)
        be -= float(add)
        if be <= 0:
            be = '0'
            Need(l[1])
            ex += float(1)

            self.db.c.execute('''UPDATE finance SET exam=? WHERE ID=?''',
                              (str(ex), t(self.tree.selection()[0], '#1')))
            self.db.c.execute('''UPDATE finance SET before=? WHERE ID=?''',
                              (str(b), t(self.tree.selection()[0], '#1')))
        else:
            self.db.c.execute('''UPDATE finance SET before=? WHERE ID=?''',
                              (str(be), t(self.tree.selection()[0], '#1')))

        self.db.c.execute('''UPDATE finance SET total=? WHERE ID=?''',
                          (to, t(self.tree.selection()[0], '#1')))
        self.db.conn.commit()
        self.view_records()

    def view_records(self):
        self.db.c.execute('''SELECT * FROM finance''')
        [self.tree.delete(i) for i in self.tree.get_children()]
        [self.tree.insert('', 'end', values=row) for row in self.db.c.fetchall()]

    def delete_records(self):
        for selection_item in self.tree.selection():
            self.db.c.execute('''DELETE FROM finance WHERE id=?''', (self.tree.set(selection_item, '#1'),))
        self.db.conn.commit()
        self.view_records()

    def search_records(self, description):
        description = ('%' + description + '%',)
        self.db.c.execute('''SELECT * FROM finance WHERE description LIKE ?''', description)
        [self.tree.delete(i) for i in self.tree.get_children()]
        [self.tree.insert('', 'end', values=row) for row in self.db.c.fetchall()]

    def open_dialog(self):
        Child()

    def open_update_dialog(self):
        Update()

    def open_search_dialog(self):
        Search()


class Editor(tk.Toplevel):
    def __init__(self):
        super().__init__(root)
        self.init_child()
        self.view = app

    def init_child(self):
        self.title('Добавить доходы/расходы')
        self.geometry('400x220+400+300')
        self.resizable(False, False)

        label_description = tk.Label(self, text='Прибавить к пробегу:')
        label_description.place(x=50, y=50)

        self.entry_description = ttk.Entry(self)
        self.entry_description.place(x=200, y=50)

        btn_cancel = ttk.Button(self, text='Закрыть', command=self.destroy)
        btn_cancel.place(x=300, y=170)

        self.btn_ok = ttk.Button(self, text='Изменить')
        self.btn_ok.place(x=220, y=170)
        self.btn_ok.bind('<Button-1>', lambda event: self.view.update_record(self.entry_description.get()))

        self.grab_set()
        self.focus_set()


class Need(tk.Toplevel):
    def __init__(self, x):
        super().__init__()
        self.init_search(x)
        self.view = app

    def init_search(self, x):
        self.title('Предупреждение')
        self.geometry('300x100+400+300')
        self.resizable(False, False)
        label_ = tk.Label(self, text='{} нуждается в ТО'.format(x))
        label_.place(x=50, y=35)
        _cancel = ttk.Button(self, text='Закрыть', command=self.destroy)
        _cancel.place(x=185, y=55)
        self.grab_set()
        self.focus_set()


class Child(tk.Toplevel):
    def __init__(self):
        super().__init__(root)
        self.init_child()
        self.view = app

    def init_child(self):
        self.title('Добавить доходы/расходы')
        self.geometry('400x220+400+300')
        self.resizable(False, False)

        label_description = tk.Label(self, text='Наименование:')
        label_description.place(x=50, y=50)
        label_select = tk.Label(self, text='Пробег')
        label_select.place(x=50, y=80)
        label_sum = tk.Label(self, text='Пробег до ТО')
        label_sum.place(x=50, y=110)
        label_ = tk.Label(self, text='Количество ТО')
        label_.place(x=50, y=140)

        self.entry_description = ttk.Entry(self)
        self.entry_description.place(x=200, y=50)

        self.entry_total = ttk.Entry(self)
        self.entry_total.place(x=200, y=80)

        self.entry_before = ttk.Entry(self)
        self.entry_before.place(x=200, y=110)

        self.entry_exam = ttk.Entry(self)
        self.entry_exam.place(x=200, y=140)

        btn_cancel = ttk.Button(self, text='Закрыть', command=self.destroy)
        btn_cancel.place(x=300, y=170)

        self.btn_ok = ttk.Button(self, text='Добавить')
        self.btn_ok.place(x=220, y=170)
        self.btn_ok.bind('<Button-1>', lambda event: self.view.records(self.entry_description.get(),
                                                                       self.entry_total.get(),
                                                                       self.entry_before.get(),
                                                                       self.entry_exam.get()))

        self.grab_set()
        self.focus_set()


class Update(Editor):
    def __init__(self):
        super().__init__()
        self.init_edit()
        self.view = app
        self.db = db
        self.default_data()

    def init_edit(self):
        self.title('Редактировать позицию')
        btn_edit = ttk.Button(self, text='Редактировать')
        btn_edit.place(x=205, y=170)
        btn_edit.bind('<Button-1>', lambda event: self.view.update_record(self.entry_description.get()))

        self.btn_ok.destroy()

    def default_data(self):
        self.db.c.execute('''SELECT * FROM finance WHERE id=?''',
                          (self.view.tree.set(self.view.tree.selection()[0], '#1')))
        row = self.db.c.fetchone()
        self.entry_description.insert(0, row[1])
        # if row[2] != 'Доход':
        # self.combobox.current(1)
        # self.entry_before.insert(0, row[3])


class Search(tk.Toplevel):
    def __init__(self):
        super().__init__()
        self.init_search()
        self.view = app

    def init_search(self):
        self.title('Поиск')
        self.geometry('300x100+400+300')
        self.resizable(False, False)

        label_search = tk.Label(self, text='Поиск')
        label_search.place(x=50, y=20)

        self.entry_search = ttk.Entry(self)
        self.entry_search.place(x=105, y=20, width=150)

        btn_cancel = ttk.Button(self, text='Закрыть', command=self.destroy)
        btn_cancel.place(x=185, y=50)

        btn_search = ttk.Button(self, text='Поиск')
        btn_search.place(x=105, y=50)
        btn_search.bind('<Button-1>', lambda event: self.view.search_records(self.entry_search.get()))
        btn_search.bind('<Button-1>', lambda event: self.destroy(), add='+')


class DB:
    def __init__(self):
        self.conn = sqlite3.connect('Probeg.db')
        self.c = self.conn.cursor()
        self.c.execute(
            '''CREATE TABLE IF NOT EXISTS finance (id integer primary key, description text, total real, before real, exam real)''')
        self.c.execute(
            '''CREATE TABLE IF NOT EXISTS BeforeExam (id integer primary key,description text, before real)''')
        self.conn.commit()

    def insert_data(self, description, total, before, exam):
        self.c.execute('''INSERT INTO finance(description, total, before, exam) VALUES (?, ?, ?, ?)''',
                       (description, total, before, exam))
        self.c.execute('''INSERT INTO BeforeExam(description, before) VALUES (?, ?)''',
                       (description, before))
        self.conn.commit()


if __name__ == "__main__":
    root = tk.Tk()
    db = DB()
    app = Main(root)
    app.pack()
    root.title("Счетчик пробегов/ТО")
    root.geometry("800x450+300+200")
    root.resizable(False, False)
    root.mainloop()